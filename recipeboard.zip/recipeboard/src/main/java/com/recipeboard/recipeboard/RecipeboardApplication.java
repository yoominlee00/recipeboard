package com.recipeboard.recipeboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecipeboardApplication {

	public static void main(String[] args) {
		SpringApplication.run(RecipeboardApplication.class, args);
	}

}
