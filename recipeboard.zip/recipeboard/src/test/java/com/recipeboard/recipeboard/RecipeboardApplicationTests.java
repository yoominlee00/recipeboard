package com.recipeboard.recipeboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecipeboardApplicationTests {

	@Test
	void contextLoads() {
	}

}
